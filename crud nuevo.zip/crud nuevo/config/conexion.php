<?php

$host = "localhost";
$user = "formulario_user";
$password = "12345";
$database = "formulario_db";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

?>