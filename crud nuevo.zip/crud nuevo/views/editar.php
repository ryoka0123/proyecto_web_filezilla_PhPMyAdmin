<?php
include '../config/conexion.php';

$id = $_GET['id'] ?? '';
if (empty($id)) {
    header("Location: listar.php");
    exit();
}

// Buscar los datos actuales del registro
$sql = "SELECT * FROM formulario WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

if (!$data) {
    die("El registro no existe.");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Registro</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: #f4f7f6; display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px; }
        .form-container { background: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); width: 100%; max-width: 500px; }
        h2 { text-align: center; margin-bottom: 20px; color: #333; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; color: #666; font-size: 14px; font-weight: bold; }
        input[type="text"], input[type="email"], select, textarea { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; }
        button { width: 100%; padding: 12px; background-color: #2196F3; border: none; border-radius: 4px; color: white; font-size: 16px; font-weight: bold; cursor: pointer; margin-top: 10px; }
        .btn-back { display: block; text-align: center; margin-top: 15px; color: #666; text-decoration: none; font-size: 14px; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Modificar Registro #<?php echo $data['id']; ?></h2>
    <form action="../php/actualizar.php" method="POST">
        <!-- Input oculto para enviar el ID al procesador -->
        <input type="hidden" name="id" value="<?php echo $data['id']; ?>">

        <div class="form-group">
            <label>Nombre Completo</label>
            <input type="text" name="nombre" value="<?php echo htmlspecialchars($data['nombre']); ?>" required>
        </div>
        <div class="form-group">
            <label>Correo Electrónico</label>
            <input type="email" name="correo" value="<?php echo htmlspecialchars($data['correo']); ?>" required>
        </div>
        <div class="form-group">
            <label>Teléfono</label>
            <input type="text" name="telefono" value="<?php echo htmlspecialchars($data['telefono']); ?>">
        </div>
        <div class="form-group">
            <label>Asunto</label>
            <input type="text" name="asunto" value="<?php echo htmlspecialchars($data['asunto']); ?>" required>
        </div>
        <div class="form-group">
            <label>Tipo de Consulta</label>
            <select name="tipo_consulta">
                <option value="General" <?php if($data['tipo_consulta'] == 'General') echo 'selected'; ?>>General</option>
                <option value="Soporte" <?php if($data['tipo_consulta'] == 'Soporte') echo 'selected'; ?>>Soporte Técnico</option>
                <option value="Sugerencia" <?php if($data['tipo_consulta'] == 'Sugerencia') echo 'selected'; ?>>Sugerencia</option>
            </select>
        </div>
        <div class="form-group">
            <label>Mensaje</label>
            <textarea name="mensaje" rows="4" required><?php echo htmlspecialchars($data['mensaje']); ?></textarea>
        </div>
        <button type="submit">Actualizar Cambios</button>
        <a href="listar.php" class="btn-back">Cancelar y Volver</a>
    </form>
</div>

</body>
</html>

