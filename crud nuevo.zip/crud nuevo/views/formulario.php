<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Registro</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: #f4f7f6; display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px; }
        .form-container { background: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); width: 100%; max-width: 500px; }
        h2 { text-align: center; margin-bottom: 20px; color: #333; font-weight: 600; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; color: #666; font-size: 14px; font-weight: bold; }
        input[type="text"], input[type="email"], select, textarea { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; transition: border-color 0.3s; }
        input:focus, select:focus, textarea:focus { border-color: #4caf50; outline: none; }
        textarea { resize: vertical; }
        button { width: 100%; padding: 12px; background-color: #4caf50; border: none; border-radius: 4px; color: white; font-size: 16px; font-weight: bold; cursor: pointer; transition: background 0.3s; margin-top: 10px; }
        button:hover { background-color: #45a049; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Formulario de Registro</h2>
    <form action="../php/guardar.php" method="POST">
        <div class="form-group">
            <label>Nombre Completo *</label>
            <input type="text" name="nombre" required placeholder="Ej. Juan Pérez">
        </div>
        <div class="form-group">
            <label>Correo Electrónico *</label>
            <input type="email" name="correo" required placeholder="ejemplo@correo.com">
        </div>
        <div class="form-group">
            <label>Teléfono</label>
            <input type="text" name="telefono" placeholder="Ej. 3227902734">
        </div>
        <div class="form-group">
            <label>Asunto del Mensaje *</label>
            <input type="text" name="asunto" required placeholder="Ej. Soporte técnico">
        </div>
        <div class="form-group">
            <label>Tipo de Consulta</label>
            <select name="tipo_consulta">
                <option value="General">General</option>
                <option value="Soporte">Soporte Técnico</option>
                <option value="Sugerencia">Sugerencia</option>
            </select>
        </div>
        <div class="form-group">
            <label>Mensaje / Comentario *</label>
            <textarea name="mensaje" rows="4" required placeholder="Escriba su mensaje aquí..."></textarea>
        </div>
        <button type="submit">Guardar Datos</button>
    </form>
</div>

</body>
</html>
