<?php 
// Forzar a PHP a mostrar cualquier error oculto de conexión o sintaxis
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../config/conexion.php'; 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Cuestionarios (CRUD)</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', sans-serif; margin: 0; padding: 0; }
        body { background-color: #f4f7f6; padding: 40px; }
        .container { max-width: 1000px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        h2 { margin-bottom: 20px; color: #333; }
        .btn-add { display: inline-block; padding: 10px 15px; background: #4caf50; color: white; text-decoration: none; border-radius: 4px; margin-bottom: 20px; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; font-size: 14px; }
        th { background-color: #f8f9fa; color: #555; }
        .btn-edit { color: #2196F3; text-decoration: none; margin-right: 10px; font-weight: bold; }
        .btn-delete { color: #F44336; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>

<div class="container">
    <h2>Registros Recibidos</h2>
    <a href="formulario.php" class="btn-add">+ Añadir Nuevo</a>
    
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Teléfono</th>
                <th>Mensaje / Respuesta</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Seleccionamos los campos reales existentes en tu base de datos
            $sql = "SELECT id, nombre, correo, telefono, mensaje FROM formulario ORDER BY id DESC";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . htmlspecialchars($row['nombre']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['correo']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['telefono']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['mensaje']) . "</td>";
                    echo "<td>
                            <a href='editar.php?id=" . $row['id'] . "' class='btn-edit'>Editar</a>
                            <a href='../php/eliminar.php?id=" . $row['id'] . "' class='btn-delete' onclick='return confirm(\"¿Seguro que deseas eliminar este registro?\")'>Eliminar</a>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6' style='text-align:center;'>No hay registros guardados en la base de datos.</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
