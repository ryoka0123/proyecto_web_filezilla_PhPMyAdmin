<?php
// Mostrar errores para depurar si algo falla
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../config/conexion.php';

$id = '';
$nombre = '';
$correo = '';
$telefono = '';
$mensaje = '';

// 1. CARGAR DATOS (Cuando el usuario da clic en Editar desde la tabla)
if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    $sql = "SELECT * FROM formulario WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        if ($fila = $resultado->fetch_assoc()) {
            $nombre   = $fila['nombre'];
            $correo   = $fila['correo'];
            $telefono = $fila['telefono'];
            $mensaje  = $fila['mensaje'];
        } else {
            die("Error: Registro no encontrado.");
        }
        $stmt->close();
    }
}

// 2. PROCESAR ACTUALIZACIÓN (Cuando el usuario da clic en "Guardar Cambios")
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id       = $_POST['id'] ?? '';
    $nombre   = $_POST['nombre'] ?? '';
    $correo   = $_POST['correo'] ?? '';
    $telefono = $_POST['telefono'] ?? '';
    $mensaje  = $_POST['mensaje'] ?? '';

    if (empty($id) || empty($nombre) || empty($correo) || empty($mensaje)) {
        die("Error: Faltan campos obligatorios.");
    }

    $sql = "UPDATE formulario SET nombre=?, correo=?, telefono=?, mensaje=? WHERE id=?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("ssssi", $nombre, $correo, $telefono, $mensaje, $id);

        if ($stmt->execute()) {
            echo "<script>
                alert('¡Registro actualizado correctamente!');
                window.location.href = '../views/listar.php';
            </script>";
            exit();
        } else {
            echo "Error al actualizar: " . $stmt->error;
        }
        $stmt->close();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Registro</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 40px; }
        .form-container { background: white; padding: 20px; border-radius: 8px; max-width: 400px; margin: 0 auto; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input, .form-group textarea { width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .btn-submit { background-color: #4CAF50; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; }
        .btn-cancel { color: #555; text-decoration: none; margin-left: 10px; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Editar Registro</h2>
    <form method="POST" action="actualizar.php">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
        
        <div class="form-group">
            <label>Nombre:</label>
            <input type="text" name="nombre" value="<?php echo htmlspecialchars($nombre); ?>" required>
        </div>

        <div class="form-group">
            <label>Correo:</label>
            <input type="email" name="correo" value="<?php echo htmlspecialchars($correo); ?>" required>
        </div>

        <div class="form-group">
            <label>Teléfono:</label>
            <input type="text" name="telefono" value="<?php echo htmlspecialchars($telefono); ?>">
        </div>

        <div class="form-group">
            <label>Mensaje:</label>
            <textarea name="mensaje" rows="4" required><?php echo htmlspecialchars($mensaje); ?></textarea>
        </div>

        <button type="submit" class="btn-submit">Guardar Cambios</button>
        <a href="../views/listar.php" class="btn-cancel">Cancelar</a>
    </form>
</div>

</body>
</html>

