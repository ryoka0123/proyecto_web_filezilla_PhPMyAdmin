<?php
include '../config/conexion.php';

$id = $_GET['id'] ?? '';

if (!empty($id)) {
    $sql = "DELETE FROM formulario WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "<script>
                alert('Registro eliminado correctamente.');
                window.location.href = '../views/listar.php';
            </script>";
        } else {
            echo "Error al eliminar: " . $stmt->error;
        }
        $stmt->close();
    }
}

$conn->close();
header("Location: ../views/listar.php");
exit();
?>
