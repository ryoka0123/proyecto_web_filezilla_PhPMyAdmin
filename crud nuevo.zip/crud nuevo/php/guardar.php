if ($stmt->execute()) {
    echo "<script>
        alert('¡Datos guardados correctamente!');
        window.location.href = '../views/listar.php';
    </script>";
}
